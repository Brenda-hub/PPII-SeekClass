<template>
  <div>
      
          {{turma}}
      
      
      
  </div>
</template>

<script>
export default {
    name: "Turmas",
    props: ["turma"],
}
</script>

<style>

</style>