<template>
  
</template>

<script>
export default {
    name: 'Disciplina',
    props: 
        ['nome', 'professor', 'link']
    
    
}
</script>

<style>

</style>